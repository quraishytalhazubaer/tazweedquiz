const TEACHER_PASSWORD = "admin786";
const STUDENT_ACCESS_CODE = "ibtra2024";

const SHEET1_URL = "";
const CONF_URL = "";

const QUESTIONS = [
        "১. লীনের হরফ কয়টি ও কী কী?",
        "২. মাদ্দে মুনফাসিল ও মাদ্দে মুত্তাসিল-এর মধ্যে পার্থক্য কী?",
        "৩. ওয়াজিব গুন্নাহ কাকে বলা হয়?",
        "৪. 'غُثَاءً أَحْوَى' - এখানে কয় আলিফ পরিমাণ টেনে পড়তে হবে?",
        "৫. নূন সাকিন বা তানওয়িন-এর পর কয়টি হরফ আসলে গুন্নাহ ছাড়া পড়তে হয়? হরফগুলো কী কী?",
];



export { TEACHER_PASSWORD, STUDENT_ACCESS_CODE, QUESTIONS, SHEET1_URL, CONF_URL };
