import React from 'react';
import { ChevronLeft, Save } from 'lucide-react';

const GradingView = ({ submission, currentMarks, setCurrentMarks, handleSave, goBack }) => (
  <div className="max-w-4xl mx-auto my-8 bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200">
    <div className="bg-slate-800 p-6 text-white flex justify-between items-center">
      <div>
        <h2 className="text-xl font-bold">{submission.userName} - এর খাতা</h2>
        <p className="text-slate-400 text-xs mt-1">ID: {submission.userId} | Branch: {submission.userBranch}</p>
      </div>
      <button onClick={goBack} className="text-slate-400 hover:text-white transition">ফিরে যান</button>
    </div>
    
    <div className="p-8 space-y-8">
      {QUESTIONS.map((q, i) => (
        <div key={i} className="bg-slate-50 p-6 rounded-xl border border-slate-100">
          <p className="font-bold text-slate-800 mb-3">{q}</p>
          <div className="bg-white p-4 rounded-lg border border-slate-200 text-emerald-700 italic">
            {submission[`q${i+1}`] || <span className="text-red-400">উত্তর প্রদান করা হয়নি</span>}
          </div>
        </div>
      ))}

      <div className="pt-6 border-t flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <label className="font-bold text-slate-700">প্রাপ্ত নম্বর (১০ এর মধ্যে):</label>
          <input 
            type="number" 
            max="10" 
            min="0"
            className="w-24 p-2 border-2 border-emerald-500 rounded-lg text-center font-bold text-xl"
            value={currentMarks}
            onChange={(e) => setCurrentMarks(e.target.value)}
          />
        </div>
        <button 
          onClick={handleSave}
          className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-xl font-bold transition shadow-lg shadow-emerald-100"
        >
          নম্বর সংরক্ষণ করুন
        </button>
      </div>
    </div>
  </div>
);

export default GradingView;