import React from "react";
import { ClipboardCheck, Clock, RefreshCw } from "lucide-react";
import { QUESTIONS } from "../constants/config";

const StudentView = ({ formData, handleChange, handleSubmit, isExamActive, submitStatus, resetStatus }) => {
  // 1. Check if submission was successful
  if (submitStatus === 'success') {
    return (
      <div className="max-w-2xl mx-auto my-12 p-12 bg-white rounded-3xl shadow-xl text-center border border-slate-100">
        <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
          <ClipboardCheck className="text-emerald-600" size={40} />
        </div>
        <h2 className="text-3xl font-bold text-slate-800 mb-4">আলহামদুলিল্লাহ!</h2>
        <p className="text-slate-600 mb-8">আপনার উত্তরপত্র সফলভাবে জমা দেওয়া হয়েছে। শিক্ষক মূল্যায়ন করার পর আপনি আপনার নম্বর জানতে পারবেন।</p>
        <button onClick={resetStatus} className="text-emerald-600 font-bold hover:underline">আরেকটি জমা দিন</button>
      </div>
    );
  }

  // 2. IMPORTANT: Check if Exam is actually active
  if (isExamActive) {
    return (
      <div className="max-w-2xl mx-auto my-12 p-12 bg-white rounded-3xl shadow-xl text-center border border-slate-100">
        <div className="bg-amber-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
          <Clock className="text-amber-600" size={40} />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-4">পরীক্ষা বর্তমানে বন্ধ আছে</h2>
        <p className="text-slate-600 mb-4">সম্মানিত শিক্ষক এখনো পরীক্ষা শুরু করেননি অথবা পরীক্ষাটি ইতোমধ্যে শেষ হয়ে গিয়েছে।</p>
        <p className="text-slate-400 text-sm">শিক্ষক পরীক্ষা শুরু করলে এখানে অটোমেটিক প্রশ্ন চলে আসবে। অথবা নিচের বাটনে ক্লিক করুন।</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-8 flex items-center gap-2 mx-auto bg-slate-900 text-white px-6 py-3 rounded-xl text-sm font-bold hover:bg-slate-800 transition shadow-lg"
        >
          <RefreshCw size={18}/> রিফ্রেশ করুন
        </button>
      </div>
    );
  }

  // 3. Show Questions if Exam is Active
  return (
    <div className="max-w-3xl mx-auto my-8 bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in fade-in duration-500">
      <div className="bg-emerald-600 p-8 text-white">
        <div className="flex justify-between items-start">
            <div>
                <h1 className="text-2xl font-bold flex items-center gap-2">তাজবীদ কুইজ - মূল্যায়ন</h1>
                <p className="text-emerald-100 text-sm mt-2 opacity-80">সঠিকভাবে উত্তর দিন এবং সময়ের দিকে খেয়াল রাখুন।</p>
            </div>
            <div className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Exam Live</div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 bg-slate-50 rounded-2xl border border-slate-100">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">নাম</label>
            <input required name="userName" value={formData.userName} onChange={handleChange} className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="আপনার নাম"/>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">এমপ্লয়ী আইডি</label>
            <input required name="userId" value={formData.userId} onChange={handleChange} className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="ID No"/>
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">শাখা/পোস্টিং</label>
            <input required name="userBranch" value={formData.userBranch} onChange={handleChange} className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="আপনার কর্মস্থল"/>
          </div>
        </div>

        <div className="space-y-10">
          {QUESTIONS.map((q, i) => (
            <div key={i} className="relative pl-6 border-l-4 border-emerald-500">
              <h3 className="font-bold text-slate-800 text-lg mb-4">{q}</h3>
              <textarea 
                required
                name={`q${i+1}`}
                value={formData[`q${i+1}`]}
                onChange={handleChange}
                rows="3"
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition"
                placeholder="আপনার উত্তর এখানে লিখুন..."
              ></textarea>
            </div>
          ))}
        </div>

        <div className="pt-6">
          <button 
            type="submit" 
            disabled={submitStatus === 'submitting'}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-400 text-white font-bold py-4 rounded-2xl text-xl shadow-xl shadow-emerald-100 transition-all active:scale-95"
          >
            {submitStatus === 'submitting' ? 'জমা হচ্ছে...' : 'উত্তরপত্র জমা দিন'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default StudentView;

