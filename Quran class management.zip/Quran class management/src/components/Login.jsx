import { useState, useEffect } from 'react';
import { AlertCircle, Lock, ShieldCheck } from 'lucide-react';
import { TEACHER_PASSWORD, STUDENT_ACCESS_CODE } from '../constants/config';

const Login = ({ onLogin }) => {
  const [role, setRole] = useState('student');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    
    if (!name.trim()) {
      setError('নাম প্রদান করুন');
      return;
    }

    if (role === 'teacher') {
      if (password !== TEACHER_PASSWORD) {
        setError('ভুল শিক্ষক পাসওয়ার্ড');
        return;
      }
    } else {
      if (password !== STUDENT_ACCESS_CODE) {
        setError('ভুল স্টুডেন্ট এক্সেস কোড');
        return;
      }
    }

    onLogin({ role, name });
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md border border-slate-100">
        <div className="text-center mb-8">
          <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="text-emerald-600" size={32} />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">IBTRA Evaluation Portal</h1>
          <p className="text-slate-500 text-sm mt-2">আপনার অ্যাকাউন্ট লগইন করুন</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="flex p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition ${role === 'student' ? 'bg-white shadow-sm text-emerald-600' : 'text-slate-500'}`}
              onClick={() => { setRole('student'); setError(''); }}
            >Student</button>
            <button
              type="button"
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition ${role === 'teacher' ? 'bg-white shadow-sm text-emerald-600' : 'text-slate-500'}`}
              onClick={() => { setRole('teacher'); setError(''); }}
            >Teacher</button>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2 tracking-wider">পুরো নাম</label>
            <input
              required
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition"
              placeholder="আপনার নাম লিখুন"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2 tracking-wider">
              {role === 'teacher' ? 'পাসওয়ার্ড' : 'এক্সেস কোড'}
            </label>
            <div className="relative">
              <input
                required
                type="password"
                className="w-full p-3 pl-10 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition"
                placeholder={role === 'teacher' ? "Teacher Password" : "Student Access Code"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <Lock className="absolute left-3 top-3.5 text-slate-400" size={18} />
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-50 text-red-600 text-xs font-bold rounded-lg flex items-center gap-2">
              <AlertCircle size={14} /> {error}
            </div>
          )}

          <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl transition shadow-lg shadow-emerald-200">
            লগইন করুন
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;