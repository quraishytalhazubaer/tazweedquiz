import React from 'react';
import { CheckSquare, Download, FileText, List, Play, Printer, RefreshCw, Square, SquareStop, ShieldCheck } from 'lucide-react';


const TeacherView = ({ 
  submissions, selectedIds, onToggleSelect, onSelectAll, 
  onExport, generateIndividualPDF, handleExamToggle, 
  generateSummaryPDF, fetchSubmissions, onGrade, isExamActive 
}) => (
  <div className="max-w-6xl mx-auto my-6 bg-white rounded-xl shadow-lg overflow-hidden border border-slate-200">
    <div className="bg-slate-800 text-white p-6 flex flex-wrap justify-between items-center gap-4">
      <h1 className="text-xl font-bold flex items-center gap-2">
        <ShieldCheck className="text-emerald-400" /> শিক্ষক ড্যাশবোর্ড
      </h1>
      
      <div className="flex flex-wrap items-center gap-3">
        <button 
          onClick={handleExamToggle}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${isExamActive ? 'bg-red-500 hover:bg-red-600' : 'bg-emerald-500 hover:bg-emerald-600'}`}
        >
          {isExamActive ? <><SquareStop size={14}/> Stop Exam</> : <><Play size={14}/> Start Exam</>}
        </button>

        {selectedIds.length > 0 && (
          <button 
            onClick={() => generateIndividualPDF(submissions.filter(s => selectedIds.includes(s.id)))}
            className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg flex items-center gap-2 text-xs font-bold"
          >
            <Printer size={16} /> Print Results ({selectedIds.length})
          </button>
        )}

        <button onClick={onExport} className="bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg flex items-center gap-2 text-xs font-bold transition">
          <Download size={16} /> Excel Export
        </button>
        
        <button onClick={generateSummaryPDF} className="bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg flex items-center gap-2 text-xs font-bold transition">
          <List size={16} /> Summary PDF
        </button>
        
        <button onClick={fetchSubmissions} className="bg-slate-700 p-2 rounded hover:bg-slate-600 transition">
          <RefreshCw size={18} />
        </button>
      </div>
    </div>

    <div className="p-6 overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-slate-50 text-slate-500 uppercase text-[10px] tracking-widest font-bold">
            <th className="p-4 w-10">
              <button onClick={onSelectAll} className="hover:text-emerald-600 transition">
                {submissions.length > 0 && selectedIds.length === submissions.length
                  ? <CheckSquare size={20} className="text-emerald-600" />
                  : <Square size={20} />
                }
              </button>
            </th>
            <th className="p-4 border-b">নাম ও আইডি</th>
            <th className="p-4 border-b">শাখা</th>
            <th className="p-4 border-b">জমার সময়</th>
            <th className="p-4 border-b text-center">স্ট্যাটাস</th>
            <th className="p-4 border-b text-center">প্রাপ্ত নম্বর</th>
            <th className="p-4 border-b text-right">অ্যাকশন</th>
          </tr>
        </thead>
        <tbody className="text-sm">
          {submissions.length === 0 ? (
            <tr>
              <td colSpan="7" className="text-center py-20 text-slate-400 italic">
                এখনো কোনো ছাত্র খাতা জমা দেয়নি।
              </td>
            </tr>
          ) : (
            submissions.map((sub) => (
              <tr key={sub.id} className={`border-b hover:bg-slate-50 transition ${selectedIds.includes(sub.id) ? 'bg-emerald-50/30' : ''}`}>
                <td className="p-4">
                  <button onClick={() => onToggleSelect(sub.id)}>
                    {selectedIds.includes(sub.id)
                      ? <CheckSquare size={20} className="text-emerald-600" />
                      : <Square size={20} />
                    }
                  </button>
                </td>
                <td className="p-4">
                  <div className="font-bold text-slate-800">{sub.userName || 'N/A'}</div>
                  <div className="text-[10px] text-slate-400">{sub.userId || 'ID Missing'}</div>
                </td>
                <td className="p-4 text-slate-600">{sub.userBranch || 'N/A'}</td>
                <td className="p-4 text-slate-500 text-[11px]">{sub.timestamp || 'N/A'}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-tighter ${
                    sub.marks ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {sub.marks ? 'Graded' : 'Pending'}
                  </span>
                </td>
                <td className="p-4 text-center font-bold text-emerald-700 text-lg">
                  {sub.marks ? `${sub.marks}/10` : '-'}
                </td>
                <td className="p-4 text-right flex justify-end gap-2">
                  <button 
                    onClick={() => generateIndividualPDF([sub])} 
                    className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition"
                  >
                    <FileText size={18} />
                  </button>
                  <button 
                    onClick={() => onGrade(sub)} 
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 rounded-lg text-xs font-bold transition shadow-sm"
                  >
                    খাতা দেখুন
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  </div>
);

export default TeacherView;