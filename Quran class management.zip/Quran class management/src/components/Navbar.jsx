import React from 'react';
import { ClipboardCheck, LogOut, User } from 'lucide-react';

const Navbar = ({ user, onLogout }) => (
  <nav className="bg-slate-900 text-white p-4 shadow-md flex justify-between items-center">
    <div className="flex items-center gap-2">
      <div className="bg-emerald-500 p-1.5 rounded-lg">
        <ClipboardCheck size={20} />
      </div>
      <span className="font-bold text-lg hidden sm:inline">IBTRA Evaluation</span>
    </div>
    <div className="flex items-center gap-4">
      <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-full">
        <User size={16} className="text-emerald-400" />
        <span className="text-sm font-medium">{user.name} ({user.role === 'teacher' ? 'শিক্ষক' : 'ছাত্র'})</span>
        <span className="hidden md:inline text-sm font-medium text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
          {user.branch || 'Main Branch'}
        </span>
      </div>
      <button 
        onClick={onLogout}
        className="flex items-center gap-1 text-red-400 hover:text-red-300 transition text-sm font-bold"
      >
        <LogOut size={18} /> <span className="hidden sm:inline">Log Out</span>
      </button>
    </div>
  </nav>
);

export default Navbar;