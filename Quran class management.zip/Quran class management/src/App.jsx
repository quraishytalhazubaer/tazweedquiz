import { useState, useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import heroImg from './assets/hero.png'
import './App.css'

import Navbar from './components/Navbar.jsx';
import Login from './components/Login';
import StudentView from './components/StudentView';
import TeacherView from './components/TeacherView';
import GradingView from './components/GradingView';

import { TEACHER_PASSWORD, STUDENT_ACCESS_CODE, SHEET1_URL, CONF_URL, QUESTIONS } from './constants/config';


export default function App() {
  const [user, setUser] = useState(null);
  const [isExamActive, setIsExamActive] = useState(false);
  const [configRowId, setConfigRowId] = useState(null); 
  const [gradingSubmission, setGradingSubmission] = useState(null);
  const [currentMarks, setCurrentMarks] = useState('');
  const [submissions, setSubmissions] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [submitStatus, setSubmitStatus] = useState(null);

  const [formData, setFormData] = useState({
    userName: '', userId: '', userBranch: '', 
    date: new Date().toISOString().split('T')[0],
    q1: '', q2: '', q3: '', q4: '', q5: ''
  });

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js";
    script.async = true;
    document.body.appendChild(script);
  }, []);

  const fetchExamStatus = async () => {
    try {
      const response = await fetch(CONF_URL);
      const data = await response.json();
      const sheet = data.sheet3 || [];
      if (sheet.length > 0) {
        const config = sheet[0];
        // Ensure robust boolean check
        const active = config.isExamActive === true || config.isExamActive === "true" || config.isExamActive === 1;
        setIsExamActive(active);
        setConfigRowId(config.id); 
      }
    } catch (error) {
      console.error("Error fetching status:", error);
    }
  };

  const fetchSubmissions = async () => {
    try {
      const response = await fetch(SHEET1_URL);
      const data = await response.json();
      setSubmissions(data.sheet1 || []);
    } catch (error) {
      console.error("Error fetching submissions:", error);
    }
  };

  useEffect(() => {
    fetchExamStatus();
    if (user?.role === 'teacher') fetchSubmissions();
    
    // Polling is active for students to react to teacher starting the exam
    const interval = setInterval(fetchExamStatus, 10000);
    return () => clearInterval(interval);
  }, [user]);

  const handleLogin = (userData) => {
    setUser(userData);
    if (userData.role === 'student') setFormData(prev => ({ ...prev, userName: userData.name }));
  };

  const handleLogout = () => {
    setUser(null);
    setGradingSubmission(null);
  };

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleStudentSubmit = async (e) => {
    e.preventDefault();
    setSubmitStatus('submitting');
    const timestamp = new Date().toLocaleString('bn-BD');
    const dataToSubmit = { ...formData, timestamp };

    try {
      const response = await fetch(SHEET1_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sheet1: dataToSubmit })
      });
      if (response.ok) setSubmitStatus('success');
      else throw new Error("Submission Failed");
    } catch (error) {
      setSubmitStatus('error');
      alert("Error: " + error.message);
    }
  };

  const handleExamToggle = async () => {
    if (!configRowId) {
        alert("Config row ID not found. Please refresh.");
        return;
    }
    const newStatus = !isExamActive;
    try {
      const response = await fetch(`${CONF_URL}/${configRowId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sheet3: { isExamActive: newStatus }
        })
      });
      if (response.ok) {
        setIsExamActive(newStatus);
      } else {
        const errData = await response.json();
        console.error("Sheety Error:", errData);
        alert("Failed to update status on server.");
      }
    } catch (error) {
      console.error("Failed to toggle exam:", error);
    }
  };

  const handleSaveMarks = async () => {
    if (!gradingSubmission) return;
    try {
      const response = await fetch(`${SHEET1_URL}/${gradingSubmission.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sheet1: { marks: currentMarks } })
      });
      if (response.ok) {
        setSubmissions(prev => prev.map(s => s.id === gradingSubmission.id ? { ...s, marks: currentMarks } : s));
        setGradingSubmission(null);
      }
    } catch (error) {
      alert("Failed to save marks");
    }
  };

  const handleExportExcel = () => {
    const headers = ["Name", "ID", "Branch", "Date", "Marks"];
    const rows = submissions.map(s => [s.userName, s.userId, s.userBranch, s.timestamp, s.marks || 0]);
    const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Results_${new Date().toLocaleDateString()}.csv`;
    link.click();
  };

  const generateSummaryPDF = () => {
    const dataToPrint = selectedIds.length > 0 
        ? submissions.filter(s => selectedIds.includes(s.id))
        : submissions;
    
    const container = document.createElement("div");
    container.style.padding = "20px";
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 20px; font-family: sans-serif;">
        <h2 style="color: #065f46;">IBTRA Tajweed Quiz Summary</h2>
        <p>Date: ${new Date().toLocaleDateString()}</p>
      </div>
      <table style="width: 100%; border-collapse: collapse; font-size: 12px; font-family: sans-serif;">
        <thead>
          <tr style="background: #f1f5f9;">
            <th style="border: 1px solid #ddd; padding: 8px;">Name</th>
            <th style="border: 1px solid #ddd; padding: 8px;">ID</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Branch</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Marks</th>
          </tr>
        </thead>
        <tbody>
          ${dataToPrint.map(s => `
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">${s.userName}</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${s.userId}</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${s.userBranch}</td>
              <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">${s.marks || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
    window.html2pdf().from(container).save("IBTRA_Summary.pdf");
  };

  const generateIndividualPDF = (dataArray) => {
    const container = document.createElement("div");
    dataArray.forEach((sub, i) => {
      const page = document.createElement("div");
      page.style.padding = "40px";
      if (i < dataArray.length - 1) page.style.pageBreakAfter = "always";
      page.innerHTML = `
        <div style="border: 2px solid #065f46; padding: 20px; font-family: sans-serif;">
          <h2 style="text-align: center; color: #065f46;">Evaluation Report</h2>
          <hr/>
          <p><strong>Name:</strong> ${sub.userName}</p>
          <p><strong>ID:</strong> ${sub.userId}</p>
          <p><strong>Branch:</strong> ${sub.userBranch}</p>
          <p><strong>Final Score:</strong> ${sub.marks || 'Pending'} / 10</p>
          <h3>Answers:</h3>
          ${QUESTIONS.map((q, idx) => `
            <div style="margin-bottom: 10px;">
              <p><strong>Q${idx+1}:</strong> ${q}</p>
              <p style="background: #f9fafb; padding: 10px; border: 1px solid #eee;">${sub['q'+(idx+1)] || 'No Answer'}</p>
            </div>
          `).join('')}
        </div>
      `;
      container.appendChild(page);
    });
    window.html2pdf().from(container).save("Individual_Results.pdf");
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {user && <Navbar user={user} onLogout={handleLogout} />}
      
      <main className="container mx-auto px-4 py-6">
        {!user && <Login onLogin={handleLogin} />}

        {user?.role === 'student' && (
          <StudentView 
            formData={formData} 
            handleChange={handleChange} 
            handleSubmit={handleStudentSubmit} 
            isExamActive={isExamActive}
            submitStatus={submitStatus}
            resetStatus={() => setSubmitStatus(null)}
          />
        )}

        {user?.role === 'teacher' && !gradingSubmission && (
          <TeacherView 
            submissions={submissions}
            selectedIds={selectedIds}
            onToggleSelect={(id) => setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id])}
            onSelectAll={() => setSelectedIds(selectedIds.length === submissions.length ? [] : submissions.map(s => s.id))}
            onGrade={(sub) => { setGradingSubmission(sub); setCurrentMarks(sub.marks || ''); }}
            handleExamToggle={handleExamToggle}
            onExport={handleExportExcel}
            generateIndividualPDF={generateIndividualPDF}
            generateSummaryPDF={generateSummaryPDF}
            fetchSubmissions={fetchSubmissions}
            isExamActive={isExamActive}
          />
        )}

        {user?.role === 'teacher' && gradingSubmission && (
          <GradingView 
            submission={gradingSubmission}
            currentMarks={currentMarks}
            setCurrentMarks={setCurrentMarks}
            handleSave={handleSaveMarks}
            goBack={() => setGradingSubmission(null)}
          />
        )}
      </main>
    </div>
  );
}
