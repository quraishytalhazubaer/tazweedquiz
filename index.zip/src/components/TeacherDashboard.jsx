import { Fragment, useState } from 'react'
import { ArrowDown, ArrowUp, ArrowUpDown, CheckSquare, ChevronDown, Download, FileText, Loader2, RefreshCw, Search, Settings, ShieldCheck } from 'lucide-react'
import AttendancePanel from './AttendancePanel'
import QuestionManagement from './QuestionManagement'

function TeacherDashboard({
  questionManagementOnly = false,
  onQuestionManagementClose,
  submissions = [],
  academicMarks = {},
  academicMarksLoading = false,
  selectedIds = [],
  setSelectedIds,
  onGrade,
  onUpdateVivaMarks,
  loading,
  onRefresh,
  isExamActive,
  setIsExamActive,
  attendance = {},
  attendanceRecords = [],
  attendanceLoading = false,
  showAttendance = true,
  onToggleAttendance,
  onRegenerateAttendance,
  onRefreshAttendance,
  searchQuery,
  setSearchQuery,
  branchFilter,
  setBranchFilter,
  triggerNotification,
  openConfigSettings,
  onExportExcel,
  activeBatches = [],
  batchQuestionSetsLoading = false,
  submissionsReady = false,
  selectedReportBatch = 'All',
  setSelectedReportBatch,
  onGenerateSummaryPDF,
  onGenerateIndividualPDF,
  onManageUsers,
  canManageExam = false,
  canEditQuestions = false,
  canViewMarks = false,
  canEditMarks = false,
  canGrade = false,
  questions = [],
  questionSets = [],
  onQuestionsChange,
  onAddQuestionSet,
  onRenameQuestionSet,
  batchQuestionSets = {},
  onSaveBatchQuestionSet,
}) {
  const [sortBy, setSortBy] = useState('id')
  const [sortDirection, setSortDirection] = useState('asc')
  const [collapsedGenderGroups, setCollapsedGenderGroups] = useState({})
  const branches = Array.from(new Set(submissions.map((sub) => sub.userBranch).filter(Boolean)))
  const getGenderSortOrder = (gender) => gender === 'male' ? 0 : gender === 'female' ? 1 : 2
  const getGenderLabel = (gender) => gender === 'male'
    ? 'Male'
    : gender === 'female'
      ? 'Female'
      : 'Not provided'

  const submissionBatches = Array.from(
    new Set(submissions.map((sub) => sub.batch || sub.userBatchGroup).filter(Boolean))
  )

  const allAvailableBatches = Array.from(
    new Set([...(activeBatches || []), ...submissionBatches].filter((batch) => batch && batch.trim() !== ''))
  )
  const columnCount = 7 + (canViewMarks ? 7 : 0) + (canViewMarks || canGrade ? 1 : 0)

  const getTotalMarksForSort = (submission) => {
    const writtenMarks = submission.marks !== undefined && submission.marks !== null
      ? parseFloat(submission.marks)
      : null
    const vivaMarks = submission.viva_marks ?? submission.vivaMarks ?? ''
    return submission.total_marks ?? submission.totalMarks ?? (
      writtenMarks !== null ? writtenMarks + (parseFloat(vivaMarks) || 0) : ''
    )
  }

  const filteredSubmissions = submissions.filter((sub) => {
    const query = searchQuery.toLowerCase()
    const matchSearch =
      (sub.userName || '').toLowerCase().includes(query) ||
      (sub.userId && sub.userId.toString().toLowerCase().includes(query)) ||
      (sub.userBranch && sub.userBranch.toLowerCase().includes(query)) ||
      getGenderLabel(sub.gender).toLowerCase().includes(query)

    const matchBranch = branchFilter
      ? (sub.userBranch || '').toLowerCase().includes(branchFilter.trim().toLowerCase())
      : true

    const subBatch = sub.batch || sub.userBatchGroup
    const matchBatch =
      !selectedReportBatch || selectedReportBatch === 'All'
        ? true
        : subBatch === selectedReportBatch

    return matchSearch && matchBranch && matchBatch
  }).sort((first, second) => {
    const genderComparison = getGenderSortOrder(first.gender) - getGenderSortOrder(second.gender)
    if (genderComparison !== 0) return genderComparison

    const firstValue = sortBy === 'id' ? first.userId : sortBy === 'marks' ? first.marks : getTotalMarksForSort(first)
    const secondValue = sortBy === 'id' ? second.userId : sortBy === 'marks' ? second.marks : getTotalMarksForSort(second)
    const firstText = String(firstValue ?? '').trim()
    const secondText = String(secondValue ?? '').trim()

    if (sortBy !== 'id') {
      const firstNumber = Number(firstText)
      const secondNumber = Number(secondText)
      const firstHasMarks = firstText !== '' && Number.isFinite(firstNumber)
      const secondHasMarks = secondText !== '' && Number.isFinite(secondNumber)

      if (!firstHasMarks && !secondHasMarks) return 0
      if (!firstHasMarks) return 1
      if (!secondHasMarks) return -1
      return sortDirection === 'asc' ? firstNumber - secondNumber : secondNumber - firstNumber
    }

    if (!firstText && !secondText) return 0
    if (!firstText) return 1
    if (!secondText) return -1

    const firstNumber = Number(firstText)
    const secondNumber = Number(secondText)
    const comparison = Number.isFinite(firstNumber) && Number.isFinite(secondNumber)
      ? firstNumber - secondNumber
      : firstText.localeCompare(secondText, undefined, { numeric: true, sensitivity: 'base' })
    return sortDirection === 'asc' ? comparison : -comparison
  })
  const serialNumbers = new Map(filteredSubmissions.map((submission, index) => (
    [submission.id, index + 1]
  )))
  const genderGroups = [
    { key: 'male', label: 'Male', order: 0 },
    { key: 'female', label: 'Female', order: 1 },
    { key: 'not-provided', label: 'Not provided', order: 2 },
  ].map((group) => ({
    ...group,
    submissions: filteredSubmissions.filter((submission) => (
      getGenderSortOrder(submission.gender) === group.order
    )),
  })).map((group) => ({
    ...group,
    vivaMarksEntered: group.submissions.filter((submission) => {
      const vivaMarks = submission.viva_marks ?? submission.vivaMarks
      return vivaMarks !== null && vivaMarks !== undefined && vivaMarks !== ''
    }).length,
  })).filter((group) => group.submissions.length > 0)

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortDirection((direction) => direction === 'asc' ? 'desc' : 'asc')
      return
    }

    setSortBy(field)
    setSortDirection(field === 'id' ? 'asc' : 'desc')
  }

  const sortIcon = (field) => {
    if (sortBy !== field) return <ArrowUpDown className="h-3.5 w-3.5 text-slate-400" />
    return sortDirection === 'asc'
      ? <ArrowUp className="h-3.5 w-3.5 text-emerald-700" />
      : <ArrowDown className="h-3.5 w-3.5 text-emerald-700" />
  }

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredSubmissions.length) {
      setSelectedIds([])
    } else {
      setSelectedIds(filteredSubmissions.map((sub) => sub.id))
    }
  }

  const toggleSelectOne = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds((prev) => prev.filter((item) => item !== id))
    } else {
      setSelectedIds((prev) => [...prev, id])
    }
  }

  const handleBulkIndividualPDF = () => {
    const selectedData = submissions.filter((s) => selectedIds.includes(s.id))
    if (selectedData.length === 0) {
      triggerNotification('দয়া করে যেকোনো শিক্ষার্থী সিলেক্ট করুন।', 'error')
      return
    }
    onGenerateIndividualPDF(selectedData, triggerNotification, questions)
  }

  return (
    <>
    {questionManagementOnly ? (
      <QuestionManagement
        questions={questions}
        questionSets={questionSets}
        onQuestionsChange={onQuestionsChange}
        onAddQuestionSet={onAddQuestionSet}
        onRenameQuestionSet={onRenameQuestionSet}
        onNotify={triggerNotification}
        onClose={onQuestionManagementClose}
        activeBatches={activeBatches}
        submissions={submissions}
        submissionsReady={submissionsReady}
        batchQuestionSets={batchQuestionSets}
        batchQuestionSetsLoading={batchQuestionSetsLoading}
        canEditQuestions={canEditQuestions}
        onSaveBatchQuestionSet={onSaveBatchQuestionSet}
      />
    ) : (
    <div className="space-y-4 sm:space-y-6 animate-slide-in">
      {/* Top Header Controls */}
      <div className="bg-white rounded-[2rem] p-6 md:p-8 shadow-sm border border-slate-200/60 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-2xl font-black text-slate-950 flex items-center gap-2">
            <ShieldCheck className="h-7 w-7 text-emerald-700" />
            পরীক্ষক ড্যাশবোর্ড (Teacher Control Desk)
          </h2>
          <p className="text-sm text-slate-500 mt-1">শিক্ষার্থীরা কুইজ পরীক্ষা জমা দিলে রিয়েল-টাইমে এখানে যুক্ত হবে।</p>
        </div>

        <div className="grid w-full grid-cols-2 gap-2 sm:flex sm:w-auto sm:flex-wrap sm:items-center sm:gap-3">
          {canManageExam && <button
            onClick={openConfigSettings}
            className="flex items-center justify-center gap-2 p-3 text-center text-xs font-bold text-slate-700 transition-all rounded-2xl border border-slate-200 bg-slate-50 hover:bg-slate-150 sm:justify-start sm:text-left"
            title="Batch Configuration"
          >
            <Settings className="h-4 w-4" /> Batch Config
          </button>}

          {onManageUsers && <button onClick={onManageUsers} className="flex items-center justify-center gap-2 p-3 text-center text-xs font-bold text-slate-700 transition-all rounded-2xl border border-slate-200 bg-slate-50 hover:bg-slate-150 sm:justify-start sm:text-left" title="User management">
            <ShieldCheck className="h-4 w-4" /> Users
          </button>}

          {canManageExam && <button
            onClick={() => setIsExamActive(!isExamActive)}
            className={`w-full justify-center text-center px-5 py-2.5 rounded-2xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all duration-200 border sm:w-auto sm:justify-start sm:text-left ${
              isExamActive
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : 'bg-rose-50 text-rose-800 border-rose-200'
            }`}
          >
            <div className={`w-2.5 h-2.5 rounded-full ${isExamActive ? 'bg-emerald-600 animate-pulse' : 'bg-rose-600'}`}></div>
            {isExamActive ? 'Exam Active (চলমান)' : 'Exam Stopped (বন্ধ)'}
          </button>}

          <button
            onClick={onRefresh}
            className="flex items-center justify-center p-3 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-2xl border border-slate-200 transition-all sm:justify-start"
            title="পুনরায় লোড করুন"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {showAttendance && (
        <AttendancePanel
          attendance={attendance}
          attendanceRecords={attendanceRecords}
          attendanceLoading={attendanceLoading}
          onToggleAttendance={onToggleAttendance}
          onRegenerateAttendance={onRegenerateAttendance}
          onRefreshAttendance={onRefreshAttendance}
          onNotify={triggerNotification}
        />
      )}

      {/* Filters and Exports Bar */}
      <div className="-mx-4 px-4 py-3 bg-slate-50/95 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        {/* Search */}
        <div className="relative col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex items-center lg:col-span-1">
          <span className="absolute left-3.5 text-slate-400">
            <Search className="h-4 w-4" />
          </span>
          <input
            type="text"
            placeholder="নাম বা আইডি দিয়ে খুঁজুন..."
            className="w-full pl-10 pr-4 py-3 bg-transparent text-sm focus:outline-none placeholder:text-slate-400 font-semibold"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Branch Filter */}
        <div className="relative min-w-0 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center">
          <select
            aria-label="Filter submissions by branch"
            className="w-full appearance-none truncate bg-transparent py-3 pl-3 pr-8 text-xs font-semibold text-slate-700 focus:outline-none sm:px-4 sm:pr-10 sm:text-sm"
            value={branchFilter}
            onChange={(e) => setBranchFilter(e.target.value)}
          >
            <option value="">সকল শাখা</option>
            {branches.map((branch) => <option key={branch} value={branch}>{branch}</option>)}
          </select>
          <ChevronDown className="pointer-events-none absolute right-2 h-4 w-4 text-slate-400 sm:right-3" />
        </div>

        {/* Dynamic Database Report Batch Selector */}
        <div className="relative min-w-0 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center">
          <select
            className="w-full appearance-none truncate bg-transparent py-3 pl-3 pr-8 text-xs font-semibold text-slate-700 focus:outline-none sm:px-4 sm:pr-10 sm:text-sm"
            value={selectedReportBatch}
            onChange={(e) => setSelectedReportBatch(e.target.value)}
          >
            <option value="All">সকল ব্যাচ (Report: All Batches)</option>
            {allAvailableBatches.map((b, idx) => (
              <option key={idx} value={b}>
                {b}
              </option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-2 h-4 w-4 text-slate-400 sm:right-3" />
        </div>

        {/* Export Buttons */}
        {canViewMarks && <div className="col-span-2 flex gap-2 lg:col-span-1">
          <button
            onClick={() => onExportExcel(filteredSubmissions, triggerNotification, questions)}
            className="flex-1 px-3 py-3 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-950 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
          >
            <Download className="h-4 w-4" /> Export CSV
          </button>
          <button
            onClick={() => onGenerateSummaryPDF(filteredSubmissions, triggerNotification, { batch: selectedReportBatch })}
            className="flex-1 px-3 py-3 bg-emerald-50 hover:bg-emerald-100 text-[#1B4D1A] font-bold rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-sm border border-emerald-200 transition-colors"
          >
            <FileText className="h-4 w-4" /> Summary PDF
          </button>
        </div>}
        </div>
        {canViewMarks && genderGroups.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2" aria-label="Viva marks progress by gender">
            {genderGroups.map((group) => {
              const progress = Math.round((group.vivaMarksEntered / group.submissions.length) * 100)
              return (
                <div key={group.key} className="min-w-[140px] flex-1 rounded-xl border border-emerald-100 bg-white px-3 py-2 shadow-sm">
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-bold text-slate-700">{group.label}</span>
                    <span className="font-black text-emerald-800">
                      {group.vivaMarksEntered}/{group.submissions.length}
                    </span>
                  </div>
                  <div
                    className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-100"
                    role="progressbar"
                    aria-label={`${group.label} viva marks entered`}
                    aria-valuemin={0}
                    aria-valuemax={group.submissions.length}
                    aria-valuenow={group.vivaMarksEntered}
                  >
                    <div className="h-full rounded-full bg-emerald-600 transition-all" style={{ width: `${progress}%` }} />
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Selection Notification Bar */}
      {canViewMarks && selectedIds.length > 0 && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center justify-between gap-4 animate-slide-in">
          <div className="flex items-center gap-2">
            <CheckSquare className="h-5 w-5 text-emerald-800" />
            <span className="text-sm font-bold text-emerald-900">{selectedIds.length} জন পরীক্ষার্থী সিলেক্ট করা হয়েছে।</span>
          </div>
          <button
            onClick={handleBulkIndividualPDF}
            className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition shadow-sm"
          >
            <FileText className="h-3.5 w-3.5" /> নির্বাচিতদের PDF ডাউনলোড
          </button>
        </div>
      )}

      {/* Submissions Table */}
      <div className="sticky top-[4.5rem] z-20 -mx-3 h-[calc(100dvh-4.5rem)] overflow-auto bg-white shadow-sm sm:mx-0 sm:rounded-3xl sm:border-x">
        <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 z-10">
              <tr className="bg-slate-50 border-b border-slate-150 text-xs font-bold uppercase text-slate-500 tracking-wider">
                {canViewMarks && <th className="py-3 px-3 text-center w-12 sm:py-4 sm:px-6">
                  <input
                    type="checkbox"
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 h-4 w-4"
                    checked={filteredSubmissions.length > 0 && selectedIds.length === filteredSubmissions.length}
                    onChange={toggleSelectAll}
                  />
                </th>}
                <th className="py-3 px-2 sm:py-4 sm:px-4">SL</th>
                <th className="py-3 px-2 sm:py-4 sm:px-4" aria-sort={sortBy === 'id' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}>
                  <button type="button" onClick={() => handleSort('id')} className="inline-flex items-center gap-1.5" aria-label={`Sort by ID ${sortBy === 'id' && sortDirection === 'asc' ? 'descending' : 'ascending'}`}>
                    আইডি {sortIcon('id')}
                  </button>
                </th>
                <th className="py-3 px-2 sm:py-4 sm:px-4">নাম</th>
                <th className="py-3 px-2 sm:py-4 sm:px-4">Gender</th>
                <th className="py-3 px-2 sm:py-4 sm:px-4">শাখা</th>
                <th className="py-3 px-2 sm:py-4 sm:px-4">ব্যাচ</th>
                <th className="py-3 px-2 sm:py-4 sm:px-4">জমাদানের সময়</th>
                {canViewMarks && <>
                  <th className="py-3 px-2 text-center sm:py-4 sm:px-4">মূল্যায়ন অবস্থা</th>
                  <th className="py-3 px-2 text-center sm:py-4 sm:px-4" aria-sort={sortBy === 'marks' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}>
                    <button type="button" onClick={() => handleSort('marks')} className="inline-flex items-center justify-center gap-1.5" aria-label={`Sort by marks ${sortBy === 'marks' && sortDirection === 'desc' ? 'ascending' : 'descending'}`}>
                      প্রাপ্ত নম্বর (১০) {sortIcon('marks')}
                    </button>
                  </th>
                  <th className="py-3 px-2 text-center sm:py-4 sm:px-4">ভাইভা (৫)</th>
                  <th className="py-3 px-2 text-center sm:py-4 sm:px-4" aria-sort={sortBy === 'totalMarks' ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}>
                    <button type="button" onClick={() => handleSort('totalMarks')} className="inline-flex items-center justify-center gap-1.5" aria-label={`Sort by total marks ${sortBy === 'totalMarks' && sortDirection === 'desc' ? 'ascending' : 'descending'}`}>
                      মোট নম্বর (১৫) {sortIcon('totalMarks')}
                    </button>
                  </th>
                  <th className="py-3 px-2 text-center sm:py-4 sm:px-4">হাজিরা (২)</th>
                  <th className="py-3 px-2 text-center sm:py-4 sm:px-4">অ্যাসাইনমেন্ট গড় (৩)</th>
                </>}
                {(canViewMarks || canGrade) && <th className="py-3 px-3 text-right sm:py-4 sm:px-6">অ্যাকশন</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {loading ? (
                <tr>
                  <td colSpan={columnCount} className="py-12 text-center text-slate-500 font-medium animate-pulse">
                    <Loader2 className="h-8 w-8 text-emerald-600 animate-spin mx-auto mb-2" />
                    মূল্যায়ন পত্র লোড করা হচ্ছে...
                  </td>
                </tr>
              ) : filteredSubmissions.length === 0 ? (
                <tr>
                  <td colSpan={columnCount} className="py-12 text-center text-slate-500">
                    কোনো পরীক্ষার্থীর উত্তরপত্র পাওয়া যায়নি।
                  </td>
                </tr>
              ) : (
                genderGroups.map((group) => (
                  <Fragment key={group.key}>
                    <tr className="bg-emerald-50 border-y border-emerald-100">
                      <td colSpan={columnCount} className="px-4 py-2 text-sm font-black text-emerald-900">
                        <button
                          type="button"
                          aria-expanded={!collapsedGenderGroups[group.key]}
                          aria-label={`${collapsedGenderGroups[group.key] ? 'Expand' : 'Collapse'} ${group.label} submissions`}
                          onClick={() => setCollapsedGenderGroups((current) => ({
                            ...current,
                            [group.key]: !current[group.key],
                          }))}
                          className="flex w-full items-center gap-2 text-left"
                        >
                          <ChevronDown className={`h-4 w-4 transition-transform ${collapsedGenderGroups[group.key] ? '-rotate-90' : ''}`} />
                          <span>{group.label}</span>
                          <span className="text-xs font-bold text-emerald-700">({group.submissions.length})</span>
                          {canViewMarks && (
                            <span className="ml-auto text-xs font-bold text-emerald-800">
                              Viva entered: {group.vivaMarksEntered}/{group.submissions.length}
                            </span>
                          )}
                        </button>
                      </td>
                    </tr>
                    {!collapsedGenderGroups[group.key] && group.submissions.map((sub, idx) => {
                  const isChecked = selectedIds.includes(sub.id)
                  
                  // Existing Written Marks
                  const existingMarks = sub.marks !== undefined && sub.marks !== null ? parseFloat(sub.marks) : null
                  const isEvaluated = existingMarks !== null

                  // Viva Marks
                  const vivaValue = sub.viva_marks ?? sub.vivaMarks ?? ''
                  
                  // Status is 'Graded' if explicitly set OR if viva marks exist
                  const isGraded = sub.status === 'Graded' || sub.status === 'graded';

                  // Total Marks
                  const totalMarks = sub.total_marks ?? sub.totalMarks ?? (
                    isEvaluated ? existingMarks + (parseFloat(vivaValue) || 0) : '---'
                  )
                  const rowAcademicMarks = academicMarks[`${sub.profileId}:${sub.batch || sub.userBatchGroup}`]

                  return (
                    <tr key={sub.id || idx} className={`hover:bg-slate-50/40 transition-colors ${isChecked ? 'bg-emerald-50/20' : ''}`}>
                      {canViewMarks && <td className="py-3 px-3 text-center sm:py-4 sm:px-6">
                        <input
                          type="checkbox"
                          className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 h-4 w-4"
                          checked={isChecked}
                          onChange={() => toggleSelectOne(sub.id)}
                        />
                      </td>}
                      <td className="py-3 px-2 text-xs text-slate-500 font-mono sm:py-4 sm:px-4">{serialNumbers.get(sub.id)}</td>
                      <td className="py-3 px-2 font-mono text-xs text-slate-600 font-bold sm:py-4 sm:px-4">{sub.userId || '---'}</td>
                      <td className="py-3 px-2 sm:py-4 sm:px-4">
                        <div className="font-bold text-slate-950">{sub.userName}</div>
                      </td>
                      <td className="py-3 px-2 text-slate-600 font-medium sm:py-4 sm:px-4">{getGenderLabel(sub.gender)}</td>
                      <td className="py-3 px-2 text-slate-600 font-medium sm:py-4 sm:px-4">{sub.userBranch || '---'}</td>
                      <td className="py-3 px-2 text-slate-600 font-medium sm:py-4 sm:px-4">{sub.batch || sub.userBatchGroup || '---'}</td>
                      <td className="py-3 px-2 text-xs text-slate-500 font-sans sm:py-4 sm:px-4">{sub.timestamp || sub.date || '---'}</td>
                      
                      {/* Evaluation Status Badge */}
                      {canViewMarks && <td className="py-3 px-2 text-center sm:py-4 sm:px-4">
                        {isGraded ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">
                            Graded
                          </span>
                        ) : isEvaluated ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Evaluated
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
                            Pending
                          </span>
                        )}
                      </td>}
                      
                      {/* Written Marks */}
                      {canViewMarks && <td className="py-3 px-2 text-center font-black text-base text-[#1B4D1A] sm:py-4 sm:px-4">
                        {isEvaluated ? existingMarks : '---'}
                      </td>}

                      {/* Viva Marks Input - Locked / Read-Only when Graded */}
                      {canViewMarks && <td className="py-3 px-2 text-center sm:py-4 sm:px-4">
                        <input
                          type="number"
                          min="0"
                          max="5"
                          step="0.5"
                          value={vivaValue}
                          disabled={!canEditMarks || isGraded}
                          readOnly={!canEditMarks || isGraded}
                          onChange={(e) => onUpdateVivaMarks && onUpdateVivaMarks(sub.id, e.target.value)}
                          placeholder="0"
                          className={`w-16 text-center py-1 rounded-lg border font-bold focus:outline-none ${
                            isGraded
                              ? 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed'
                              : 'bg-white border-slate-300 text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500'
                          }`}
                        />
                      </td>}

                      {/* Total Marks */}
                      {canViewMarks && <td className="py-3 px-2 text-center font-black text-base text-emerald-800 sm:py-4 sm:px-4">
                        {totalMarks}
                      </td>}

                      {canViewMarks && <td className="py-3 px-2 text-center font-bold text-emerald-800 sm:py-4 sm:px-4">
                        {academicMarksLoading
                          ? '...'
                          : rowAcademicMarks?.attendanceMarks == null
                            ? '---'
                            : `${Number(rowAcademicMarks.attendanceMarks).toFixed(2)} / 2`}
                      </td>}
                      {canViewMarks && <td className="py-3 px-2 text-center font-bold text-sky-800 sm:py-4 sm:px-4">
                        {academicMarksLoading
                          ? '...'
                          : rowAcademicMarks?.assignmentMarks == null
                            ? '---'
                            : `${Number(rowAcademicMarks.assignmentMarks).toFixed(2)} / 3`}
                      </td>}

                      {(canViewMarks || canGrade) && <td className="py-3 px-3 sm:py-4 sm:px-6">
                        <div className="flex flex-wrap items-center gap-2 sm:justify-end">
                          {canViewMarks && <button
                            onClick={() => onGenerateIndividualPDF([sub], triggerNotification, questions)}
                            className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-emerald-700 sm:h-auto sm:w-auto sm:p-2"
                            title="পিডিএফ ডাউনলোড"
                          >
                            <FileText className="h-4.5 w-4.5" />
                          </button>}
                          {canGrade && <button
                            onClick={() => onGrade(sub)}
                            className="inline-flex min-h-11 items-center justify-center rounded-xl bg-green-900 px-4 py-1.5 text-xs font-bold text-white transition hover:bg-green-500 hover:text-black active:bg-black"
                          >
                            Check
                          </button>}
                        </div>
                      </td>}
                    </tr>
                    )
                  })}
                  </Fragment>
                ))
              )}
            </tbody>
        </table>
      </div>
    </div>
    )}
    </>
  )
}

export default TeacherDashboard