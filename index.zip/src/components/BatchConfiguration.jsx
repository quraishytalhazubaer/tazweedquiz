import { useState } from 'react';
import { Plus, Layers, Check, Loader2, Settings } from 'lucide-react';

export default function BatchConfiguration({
  onSaveConfig,
  currentActiveBatches = [],
  currentAllBatches = [],
  currentBatchDateRanges = {},
  submissions = [],
  triggerNotification,
  onToggleAllGraded,
  canToggleAllGraded = false,
}) {
  const [activeBatches, setActiveBatches] = useState(currentActiveBatches);
  const [allBatches, setAllBatches] = useState(() => {
    const existingSubBatches = (submissions || [])
      .map((sub) => sub?.batch || sub?.userBatchGroup)
      .filter(Boolean);
    return Array.from(new Set([
      ...(currentAllBatches || []),
      ...(currentActiveBatches || []),
      ...existingSubBatches,
    ])).filter((batch) => batch && typeof batch === 'string' && batch.trim() !== '');
  });
  const [newBatchName, setNewBatchName] = useState('');
  const [saving, setSaving] = useState(false);
  const [batchDateRanges, setBatchDateRanges] = useState(currentBatchDateRanges);

  // Checks if EVERY submission currently has status 'Graded'
  const isAllGraded =
    submissions.length > 0 &&
    submissions.every(
      (sub) => sub.status === 'Graded' || sub.status === 'graded'
    )

  const handleToggle = () => {
    // If all are graded, toggle back to Evaluated (false), otherwise set all to Graded (true)
    const nextGradedState = !isAllGraded
    onToggleAllGraded(nextGradedState)
  }

  const handleToggleBatch = (batchName) => {
    setActiveBatches((prev) =>
      prev.includes(batchName)
        ? prev.filter((b) => b !== batchName)
        : [...prev, batchName]
    );
  };

  const handleAddBatch = (e) => {
    e.preventDefault();
    const trimmed = newBatchName.trim().replace(/\s+/g, '_');
    if (!trimmed) return;

    if (allBatches.some((b) => b.toLowerCase() === trimmed.toLowerCase())) {
      triggerNotification('এই ব্যাচটি ইতোমধ্যে তালিকায় রয়েছে।', 'error');
      return;
    }

    setAllBatches((prev) => [...prev, trimmed]);
    setActiveBatches((prev) => [...prev, trimmed]);
    setBatchDateRanges((current) => ({ ...current, [trimmed]: { startDate: '', endDate: '' } }));
    setNewBatchName('');
    triggerNotification(`ব্যাচ "${trimmed}" তৈরি ও সক্রিয় করা হয়েছে।`, 'success');
  };

  const updateBatchDate = (batch, field, value) => {
    setBatchDateRanges((current) => ({
      ...current,
      [batch]: { ...(current[batch] || {}), [field]: value },
    }));
  };

  const handleSave = async () => {
    const invalidBatch = allBatches.find((batch) => {
      const range = batchDateRanges[batch];
      return !range?.startDate || !range?.endDate || range.startDate > range.endDate;
    });
    if (invalidBatch) {
      triggerNotification(`${invalidBatch} ব্যাচের সঠিক শুরু ও শেষ তারিখ দিন।`, 'error');
      return;
    }

    setSaving(true);
    try {
      await onSaveConfig({
        activeBatches,
        allBatches,
        batchDateRanges,
      });
    } catch (err) {
      console.error('Failed to save batch config:', err);
      triggerNotification('সেটিংস আপডেট করতে ব্যর্থ হয়েছে।', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="space-y-5 animate-slide-in">
      <div className="bg-white rounded-3xl w-full p-6 md:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-emerald-50 rounded-2xl text-emerald-800">
              <Settings className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-950">ব্যাচ কনফিগারেশন (Batch Configuration)</h2>
              <p className="text-xs text-slate-500 font-medium">ব্যাচ, সক্রিয় অবস্থা এবং হাজিরার তারিখসীমা পরিচালনা করুন</p>
            </div>
          </div>
        </div>

        {/* Status Toggle Row */}
        {canToggleAllGraded && <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
          <div>
            <p className="font-bold text-sm text-slate-800">
              সকল রেজাল্ট {isAllGraded ? 'Graded' : 'Evaluated'} অবস্থায় আছে
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              {isAllGraded
                ? 'অফ করলে সকল রেকর্ড Evaluated হবে।'
                : 'অন করলে সকল রেকর্ড Graded হবে।'}
            </p>
          </div>

          <button
            type="button"
            role="switch"
            aria-checked={isAllGraded}
            onClick={handleToggle}
            className={`relative inline-flex h-7 w-12 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              isAllGraded ? 'bg-emerald-600' : 'bg-slate-300'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                isAllGraded ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>}

        {/* Active Batches Selection Panel */}
        <div className="space-y-3">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="h-4 w-4 text-emerald-700" />
            ব্যাচ পরিচালনা (Active / Archived)
          </label>
          
          <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-3 bg-slate-50/50 rounded-2xl border border-slate-150">
            {allBatches.map((batch) => {
              const isActive = activeBatches.includes(batch);
              return (
                <button
                  key={batch}
                  type="button"
                  onClick={() => handleToggleBatch(batch)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                    isActive
                      ? 'bg-emerald-700 text-white border-emerald-800 shadow-sm'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-white' : 'bg-slate-300'}`} />
                  {batch}
                  {isActive ? <Check className="h-3.5 w-3.5 ml-1" /> : <span className="text-[10px] font-black uppercase text-slate-400">Archived</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Create New Batch Form */}
        <form onSubmit={handleAddBatch} className="space-y-2">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
            নতুন ব্যাচ যোগ করুন (Create New Batch)
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={newBatchName}
              onChange={(e) => setNewBatchName(e.target.value)}
              placeholder="e.g. Batch_C, Morning_Shift"
              className="flex-1 px-4 py-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs font-bold focus:outline-none focus:border-emerald-600 focus:bg-white transition"
            />
            <button
              type="submit"
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition active:scale-95"
            >
              <Plus className="h-4 w-4" /> যোগ করুন
            </button>
          </div>
        </form>

        <div className="space-y-3">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">ব্যাচের তারিখসীমা (Attendance Period)</h4>
            <p className="mt-1 text-xs text-slate-500">প্রতিটি ব্যাচের শুরু ও শেষ তারিখসহ উপস্থিতির নম্বর হিসাব হবে।</p>
          </div>
          <div className="max-h-64 space-y-2 overflow-y-auto">
            {allBatches.map((batch) => (
              <div key={batch} className="grid gap-3 rounded-xl border border-slate-200 p-3 sm:grid-cols-[minmax(0,1fr)_1fr_1fr] sm:items-end">
                <p className="text-sm font-bold text-slate-800">{batch}</p>
                <label className="text-xs font-semibold text-slate-600">
                  শুরু
                  <input
                    type="date"
                    value={batchDateRanges[batch]?.startDate || ''}
                    max={batchDateRanges[batch]?.endDate || undefined}
                    onChange={(event) => updateBatchDate(batch, 'startDate', event.target.value)}
                    aria-label={`${batch} ব্যাচের শুরু তারিখ`}
                    className="mt-1 block w-full rounded-lg border border-slate-200 px-2 py-2 text-sm"
                  />
                </label>
                <label className="text-xs font-semibold text-slate-600">
                  শেষ
                  <input
                    type="date"
                    value={batchDateRanges[batch]?.endDate || ''}
                    min={batchDateRanges[batch]?.startDate || undefined}
                    onChange={(event) => updateBatchDate(batch, 'endDate', event.target.value)}
                    aria-label={`${batch} ব্যাচের শেষ তারিখ`}
                    className="mt-1 block w-full rounded-lg border border-slate-200 px-2 py-2 text-sm"
                  />
                </label>
              </div>
            ))}
            {!allBatches.length && <p className="text-sm text-slate-500">আগে একটি ব্যাচ যোগ করুন।</p>}
          </div>
        </div>

        {/* Page Actions */}
        <div className="flex justify-end gap-3 border-t border-slate-100 pt-4">
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-950 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-sm transition disabled:opacity-50"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            সেভ করুন (Save Settings)
          </button>
        </div>
      </div>
    </section>
  );
}